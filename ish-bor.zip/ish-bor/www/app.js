(function () {
'use strict';

/* ---------- ёрдамчи функциялар ---------- */
var $ = function (s) { return document.querySelector(s); };
var esc = function (s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
};
var cssEsc = function (s) { return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^\w-]/g, '\\$&'); };

/* ---------- маълумотлар рўйхати ---------- */
var FIELDS = ['Савдо', 'Қурилиш', 'Ҳайдовчи', 'Умумий овқатланиш', 'Таълим', 'IT ва дизайн', 'Ишлаб чиқариш', 'Хизмат кўрсатиш', 'Қишлоқ хўжалиги', 'Бошқа'];
var REGIONS = ['Тошкент шаҳри', 'Тошкент вилояти', 'Самарқанд', 'Бухоро', 'Андижон', 'Фарғона', 'Наманган', 'Қашқадарё', 'Сурхондарё', 'Хоразм', 'Навоий', 'Жиззах', 'Сирдарё', 'Қорақалпоғистон'];
var SCHEDULES = ['Тўлиқ иш куни', 'Ярим кун', 'Сменали', 'Масофавий', 'Бир марталик иш'];
var SORTS = [['new', 'Янгилари олдин'], ['high', 'Маоши баланд олдин']];
var KIND = {
  vacancy: { fab: 'Вакансия бериш', pay: 'Маош', who: 'Ташкилот ёки ишга олувчи', what: 'Лавозим', ph: 'Масалан: Сотувчи-кассир', empty: 'Ҳали вакансия йўқ', sheet: 'Янги вакансия', textPh: 'Нима иш қилинади, қандай талаблар бор, иш вақти…', closed: 'Ўрин тўлди', unit: ' та вакансия' },
  resume: { fab: 'Резюме бериш', pay: 'Кутилган маош', who: 'Исмингиз', what: 'Қандай иш излайсиз', ph: 'Масалан: Ҳайдовчи, Дастурчи', empty: 'Ҳали резюме йўқ', sheet: 'Янги резюме', textPh: 'Тажрибангиз, ўқишингиз, қандай ишга тайёрсиз…', closed: 'Иш топилди', unit: ' та резюме' }
};
var LIMITS = { jobs: 300, title: 80, who: 60, text: 800, cooldownMs: 20000 };
var STORE_KEY = 'ishbor_jobs_v1', FAV_KEY = 'ishbor_favs_v1', SEED_KEY = 'ishbor_seeded_v1', LAST_KEY = 'ishbor_last_post_v1';
var HEART = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-4.6-9.3-9A5.3 5.3 0 0 1 12 6.6 5.3 5.3 0 0 1 21.3 12C19 16.4 12 21 12 21z"/></svg>';
var XICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';

/* ---------- ҳолат ---------- */
var S = { kind: 'vacancy', q: '', field: 'all', region: '', sort: 'new', fav: false };
var jobs = [], loaded = false, memOnly = false, favs = new Set();
var sheetKind = null, sheetId = null, sheetPushed = false, lastFocus = null, toastTimer = null, lastSig = '';

/* ---------- браузер хотираси (хатодан ҳимояланган) ---------- */
function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); return true; } catch (e) { return false; } }
try {
  var fv = JSON.parse(lsGet(FAV_KEY) || '[]');
  if (Array.isArray(fv)) favs = new Set(fv.filter(function (x) { return typeof x === 'string'; }).slice(0, 500));
} catch (e) { /* бузилган маълумот эътиборга олинмайди */ }
function saveFavs() { lsSet(FAV_KEY, JSON.stringify(Array.from(favs))); }

/* ---------- форматлаш ---------- */
function fmtNum(n) { return Number(n).toLocaleString('ru-RU').replace(/[  ]/g, ' '); }
function fmtPhone(d) { return '+998 ' + d.slice(3, 5) + ' ' + d.slice(5, 8) + ' ' + d.slice(8, 10) + ' ' + d.slice(10, 12); }
function payText(j) {
  if (j.payFrom && j.payTo && j.payTo !== j.payFrom) return fmtNum(j.payFrom) + ' – ' + fmtNum(j.payTo) + ' сўм';
  if (j.payFrom) return fmtNum(j.payFrom) + ' сўмдан';
  return 'Маош келишилади';
}
function timeAgo(ms) {
  var d = Date.now() - ms;
  if (!(ms > 0)) return '';
  if (d < 60000) return 'ҳозиргина';
  var m = Math.floor(d / 60000); if (m < 60) return m + ' дақиқа аввал';
  var h = Math.floor(m / 60); if (h < 24) return h + ' соат аввал';
  var k = Math.floor(h / 24); if (k < 7) return k + ' кун аввал';
  var t = new Date(ms), p = function (x) { return (x < 10 ? '0' : '') + x; };
  return p(t.getDate()) + '.' + p(t.getMonth() + 1) + '.' + t.getFullYear();
}
function newId() {
  var r = '';
  try { var a = new Uint32Array(2); crypto.getRandomValues(a); r = a[0].toString(36) + a[1].toString(36); } catch (e) { r = Math.random().toString(36).slice(2, 12); }
  return 'j' + Date.now().toString(36) + r;
}

/* ---------- текшириш: ҳар бир ёзув сақлашдан ва ўқишдан олдин тозаланади ---------- */
function cleanText(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F​-‏‪-‮⁦-⁩]/g, '').slice(0, max);
}
function norm(r) {
  if (!r || typeof r !== 'object') return null;
  var title = cleanText(r.title, LIMITS.title).trim();
  if (!title) return null;
  var num = function (v) { return (typeof v === 'number' && isFinite(v) && v > 0 && v < 1e11) ? Math.round(v) : null; };
  var from = num(r.payFrom), to = num(r.payTo);
  if (from && to && to < from) { var t = from; from = to; to = t; }
  if (!from && to) { from = to; to = null; }
  var id = /^[A-Za-z0-9_-]{1,60}$/.test(String(r.id || '')) ? String(r.id) : newId();
  return {
    id: id, kind: r.kind === 'resume' ? 'resume' : 'vacancy', title: title,
    who: cleanText(r.who, LIMITS.who).trim(),
    field: FIELDS.indexOf(r.field) > -1 ? r.field : 'Бошқа',
    payFrom: from, payTo: to,
    region: REGIONS.indexOf(r.region) > -1 ? r.region : '',
    schedule: SCHEDULES.indexOf(r.schedule) > -1 ? r.schedule : '',
    phone: /^998\d{9}$/.test(String(r.phone || '')) ? String(r.phone) : '',
    text: cleanText(r.text, LIMITS.text),
    createdAt: (typeof r.createdAt === 'number' && isFinite(r.createdAt) && r.createdAt > 0) ? r.createdAt : 0,
    closed: !!r.closed, sample: !!r.sample
  };
}
/* Эълон матнида хавфли нарсалар бўлмаслиги керак: ҳавола, карта рақами */
function textProblem(s) {
  if (/(https?:\/\/|www\.|t\.me\/|\.(com|uz|ru|org|net|me|ly|io)\b|@[a-z0-9_]{4,})/i.test(s)) return 'Эълонда сайт ёки ҳавола ёзиш мумкин эмас.';
  if (/(?:\d[ -]?){13,19}/.test(s)) return 'Банк картаси ёки узун рақамларни ёзманг.';
  return '';
}

/* ---------- намуна эълонлар ---------- */
function sampleJobs() {
  var now = Date.now(), min = 60000;
  function s(kind, title, who, field, from, to, region, sched, text, ago) {
    return { id: newId(), kind: kind, title: title, who: who, field: field, payFrom: from, payTo: to, region: region, schedule: sched, phone: '998900000000', text: text, createdAt: now - ago * min, closed: false, sample: true };
  }
  return [
    s('vacancy', 'Сотувчи-кассир', '«Яшил бозор» дўкони', 'Савдо', 3000000, 3800000, 'Тошкент шаҳри', 'Сменали', 'Озиқ-овқат дўконига. Иш куни 6/1. Тажриба шарт эмас, ўргатамиз.\nКераклиги: ҳалоллик, мулоқот қила олиш.', 50),
    s('vacancy', 'Юк машинаси ҳайдовчиси (C тоифа)', '«Транс-Сервис» МЧЖ', 'Ҳайдовчи', 6000000, 9000000, 'Самарқанд', 'Тўлиқ иш куни', 'Шаҳарлараро юк ташиш. Камида 3 йиллик тажриба керак. Командировка пуллари алоҳида тўланади.', 60 * 7),
    s('vacancy', 'Уста-плиточник', 'Қурилиш бригадаси', 'Қурилиш', 250000, 350000, 'Бухоро', 'Бир марталик иш', 'Янги уйда плитка ётқизиш. Тўлов кунига. Ўз асбоби бўлса, яхши.', 60 * 30),
    s('resume', 'Ҳайдовчи (B, C тоифа)', 'Аброр, 34 ёш', 'Ҳайдовчи', 5000000, null, 'Фарғона', 'Тўлиқ иш куни', '10 йиллик тажриба, ҳужжатлар тайёр. Дўкон ёки корхонага юк ташишга тайёрман.', 60 * 5),
    s('resume', 'Ошпаз ёрдамчиси', 'Малика', 'Умумий овқатланиш', null, null, 'Тошкент шаҳри', 'Ярим кун', 'Ошхонада 2 йил ишлаганман. Ярим кун ёки сменада ишлашга тайёрман.', 60 * 20)
  ];
}

/* ---------- сақлаш қатлами. Кейинчалик интернетдаги базага шу ерда уланади ---------- */
var store = {
  persist: function () {
    if (memOnly) return;
    if (!lsSet(STORE_KEY, JSON.stringify(jobs))) throw new Error('storage');
  },
  load: function () {
    if (!lsSet('ishbor_probe', '1')) memOnly = true; else { try { localStorage.removeItem('ishbor_probe'); } catch (e) {} }
    var arr = null;
    try { arr = JSON.parse(lsGet(STORE_KEY) || 'null'); } catch (e) { arr = null; }
    if (!Array.isArray(arr)) {
      arr = [];
      if (!lsGet(SEED_KEY)) { arr = sampleJobs(); lsSet(SEED_KEY, '1'); }
    }
    var seen = {};
    jobs = arr.slice(0, LIMITS.jobs * 2).map(norm).filter(function (j) {
      if (!j || seen[j.id]) return false; seen[j.id] = 1; return true;
    });
    try { store.persist(); } catch (e) {}
    loaded = true;
  },
  add: function (j) {
    var next = [j].concat(jobs);
    if (next.length > LIMITS.jobs) throw new Error('limit');
    var prev = jobs; jobs = next;
    try { store.persist(); } catch (e) { jobs = prev; throw e; }
  },
  update: function (id, patch) {
    var prev = jobs;
    jobs = jobs.map(function (x) { return x.id === id ? norm(Object.assign({}, x, patch)) : x; });
    try { store.persist(); } catch (e) { jobs = prev; throw e; }
  },
  remove: function (id) {
    var prev = jobs; jobs = jobs.filter(function (x) { return x.id !== id; });
    try { store.persist(); } catch (e) { jobs = prev; throw e; }
  },
  removeSamples: function () {
    var prev = jobs; jobs = jobs.filter(function (x) { return !x.sample; });
    try { store.persist(); } catch (e) { jobs = prev; throw e; }
  }
};

/* ---------- рўйхат ---------- */
function filtered() {
  var q = S.q.trim().toLowerCase();
  var r = jobs.filter(function (j) {
    return j.kind === S.kind && (S.field === 'all' || j.field === S.field) && (!S.region || j.region === S.region) &&
      (!S.fav || favs.has(j.id)) && (!q || (j.title + ' ' + j.who + ' ' + j.text + ' ' + j.field + ' ' + j.region).toLowerCase().indexOf(q) > -1);
  });
  r.sort(function (a, b) {
    if (a.closed !== b.closed) return a.closed ? 1 : -1;
    if (S.sort === 'high') { var d = (b.payTo || b.payFrom || 0) - (a.payTo || a.payFrom || 0); if (d) return d; }
    return b.createdAt - a.createdAt;
  });
  return r;
}
function cardHtml(j) {
  var isNew = !j.closed && !j.sample && j.createdAt && (Date.now() - j.createdAt < 864e5), fav = favs.has(j.id);
  var meta = [j.region, j.schedule, timeAgo(j.createdAt)].filter(Boolean).join(' · ');
  var hasPay = j.payFrom || j.payTo;
  return '<article class="card' + (j.closed ? ' is-closed' : '') + '"><button type="button" class="card-main" data-open="' + esc(j.id) + '">' +
    '<span class="pills"><span class="pill">' + esc(j.field) + '</span>' + (isNew ? '<span class="pill new">ЯНГИ</span>' : '') +
    (j.closed ? '<span class="pill badge">' + esc(KIND[j.kind].closed) + '</span>' : '') + (j.sample ? '<span class="pill soft">Намуна</span>' : '') + '</span>' +
    '<span class="ctitle">' + esc(j.title) + '</span>' + (j.who ? '<span class="cwho">' + esc(j.who) + '</span>' : '') +
    '<span class="pay' + (hasPay ? '' : ' none') + '">' + esc(payText(j)) + '</span><span class="cmeta">' + esc(meta) + '</span></button>' +
    '<button type="button" class="favb" data-fav="' + esc(j.id) + '" aria-pressed="' + fav + '" aria-label="' + (fav ? 'Сақланганлардан олиб ташлаш' : 'Сақлаб қўйиш') + ': ' + esc(j.title) + '">' + HEART + '</button></article>';
}
function emptyHtml(t, p, b) { return '<div class="empty"><h2>' + esc(t) + '</h2><p>' + esc(p) + '</p>' + (b ? '<div class="btns">' + b + '</div>' : '') + '</div>'; }
function renderNote() {
  var n = $('#note'), hasSample = jobs.some(function (j) { return j.sample; }), parts = [];
  if (memOnly) parts.push('<span>Хотира ёпиқ: ёпилганда эълонлар йўқолади.</span>');
  else parts.push('<span>Эълонлар фақат шу телефонда сақланади.</span>');
  if (hasSample) parts.push('<button type="button" data-act="rmsamples">Намуналарни ўчириш</button>');
  n.innerHTML = parts.join(''); n.hidden = false;
}
function renderList() {
  var list = $('#list'), count = $('#count');
  list.setAttribute('aria-busy', 'false');
  var items = filtered(), K = KIND[S.kind];
  count.textContent = items.length + K.unit;
  if (!items.length) {
    var any = jobs.some(function (j) { return j.kind === S.kind; });
    if (!any) list.innerHTML = emptyHtml(K.empty, 'Биринчи бўлиб қўшинг.', '<button type="button" class="btn primary" data-act="add">' + esc(K.fab) + '</button>');
    else if (S.fav && !favs.size) list.innerHTML = emptyHtml('Сақланган эълон йўқ', 'Эълондаги юрак белгисини босинг, у шу ерда қолади.', '<button type="button" class="btn" data-act="clear">Ҳаммасини кўриш</button>');
    else list.innerHTML = emptyHtml('Ҳеч нарса топилмади', 'Қидирув сўзини ёки фильтрларни ўзгартириб кўринг.', '<button type="button" class="btn" data-act="clear">Фильтрларни тозалаш</button>');
    return;
  }
  list.innerHTML = items.map(cardHtml).join('');
}
function render() { renderNote(); renderList(); }
function renderChips() {
  var all = ['Ҳаммаси'].concat(FIELDS);
  $('#chips').innerHTML = all.map(function (n, i) {
    var id = i ? n : 'all';
    return '<button type="button" class="chip" data-field="' + esc(id) + '" aria-pressed="' + (S.field === id) + '">' + esc(n) + '</button>';
  }).join('');
}
function syncUi() {
  Array.prototype.forEach.call(document.querySelectorAll('#chips .chip'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-field') === S.field)); });
  Array.prototype.forEach.call(document.querySelectorAll('.switch button'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-kind') === S.kind)); });
  $('#favBtn').setAttribute('aria-pressed', String(S.fav));
  $('#region').value = S.region; $('#sort').value = S.sort; $('#q').value = S.q;
  $('#fabText').textContent = KIND[S.kind].fab;
}
function resetFilters() { S.q = ''; S.field = 'all'; S.region = ''; S.fav = false; syncUi(); }
function renderTools() {
  $('#region').innerHTML = '<option value="">Бутун Ўзбекистон</option>' + REGIONS.map(function (r) { return '<option value="' + esc(r) + '">' + esc(r) + '</option>'; }).join('');
  $('#sort').innerHTML = SORTS.map(function (s) { return '<option value="' + s[0] + '">' + s[1] + '</option>'; }).join('');
}
function toast(m) {
  var t = $('#toast'); t.textContent = m; t.classList.add('on');
  clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('on'); }, 2800);
}
function toggleFav(id) {
  var on; if (favs.has(id)) { favs.delete(id); on = false; } else { favs.add(id); on = true; }
  saveFavs();
  if (S.fav) renderList();
  else Array.prototype.forEach.call(document.querySelectorAll('[data-fav="' + cssEsc(id) + '"]'), function (b) { b.setAttribute('aria-pressed', String(on)); });
  var d = document.querySelector('#panel [data-act="fav"]');
  if (d && sheetId === id) { d.setAttribute('aria-pressed', String(on)); d.querySelector('span').textContent = on ? 'Сақланган' : 'Сақлаб қўйиш'; }
  toast(on ? 'Сақланганларга қўшилди' : 'Сақланганлардан олиб ташланди');
}

/* ---------- қуйидан чиқадиган ойна. Орқага тугмаси ойнани ёпади ---------- */
function openSheet(kind, html, id) {
  lastFocus = document.activeElement; sheetKind = kind; sheetId = id || null;
  var p = $('#panel'); p.innerHTML = html; $('#sheet').hidden = false;
  $('#app').inert = true; document.body.classList.add('lock'); p.scrollTop = 0;
  try { history.pushState({ ishborSheet: 1 }, ''); sheetPushed = true; } catch (e) { sheetPushed = false; }
  var f = p.querySelector('[data-act="close"]'); (f || p).focus();
}
function finishClose() {
  if (!sheetKind) return;
  $('#sheet').hidden = true; $('#app').inert = false; document.body.classList.remove('lock');
  sheetKind = null; sheetId = null; sheetPushed = false;
  if (lastFocus && lastFocus.focus && document.contains(lastFocus)) lastFocus.focus();
}
function closeSheet() {
  if (!sheetKind) return;
  if (sheetPushed) { try { history.back(); return; } catch (e) { /* пастга тушади */ } }
  finishClose();
}
window.addEventListener('popstate', function () { if (sheetKind) finishClose(); });

function findJob(id) { for (var i = 0; i < jobs.length; i++) { if (jobs[i].id === id) return jobs[i]; } return null; }
function fact(a, b) { return b ? '<div class="fact"><span>' + esc(a) + '</span><span>' + esc(b) + '</span></div>' : ''; }
function tipHtml(kind) {
  var li = kind === 'vacancy'
    ? ['Ишга олинишдан олдин пул ўтказманг (тўлов, «тренинг», «бронь» ва шунга ўхшашлар). Ишончли ташкилот пул сўрамайди.', 'Учрашувни одамлар кўп жойда ўтказинг ва қаерга боришингизни яқинингизга айтинг.', 'Паспорт, банк картаси ва СМС кодларини ҳеч кимга юборманг.']
    : ['Номзод билан учрашувни одамлар кўп жойда ўтказинг.', 'Ишни бошлашдан олдин шартларни ёзма келишиб олинг.', 'Банк картаси ва СМС кодларни сўраманг ва бериманг.'];
  return '<div class="tip"><b>Хавфсизлик маслаҳати</b><ul>' + li.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>';
}
function detailHtml(j) {
  var K = KIND[j.kind], fav = favs.has(j.id), hasPay = j.payFrom || j.payTo;
  var contact = j.phone ? '<section class="contact"><h3>Боғланиш</h3><p class="phone" id="phoneText">' + esc(fmtPhone(j.phone)) + '</p><div class="row"><a class="btn primary" href="tel:+' + j.phone + '">Қўнғироқ қилиш</a><button type="button" class="btn" data-act="copy">Нусха олиш</button></div></section>' : '';
  var owner = '<div class="owner"><button type="button" class="btn" data-act="closed">' + (j.closed ? 'Яна фаол қилиш' : '«' + esc(K.closed) + '» деб белгилаш') + '</button><button type="button" class="btn danger" data-act="del">Эълонни ўчириш</button>' +
    '<div class="confirm" id="confirmBox" hidden><p>Эълон ўчирилса, қайтариб бўлмайди.</p><div class="row"><button type="button" class="btn danger" data-act="delyes">Ҳа, ўчирилсин</button><button type="button" class="btn" data-act="delno">Бекор қилиш</button></div></div></div>';
  return '<div class="sheet-head"><span class="pills"><span class="pill">' + esc(j.field) + '</span>' + (j.closed ? '<span class="pill badge">' + esc(K.closed) + '</span>' : '') + (j.sample ? '<span class="pill soft">Намуна</span>' : '') + '</span>' +
    '<button type="button" class="icon-btn" data-act="close" aria-label="Ёпиш">' + XICON + '</button></div>' +
    '<h2 class="d-title" id="sheetTitle">' + esc(j.title) + '</h2><span class="pay' + (hasPay ? '' : ' none') + '">' + esc(payText(j)) + '</span>' +
    '<div class="facts">' + fact(j.kind === 'vacancy' ? 'Ташкилот' : 'Ном', j.who) + fact('Ҳудуд', j.region) + fact('Иш тартиби', j.schedule) + fact('Эълон берилди', timeAgo(j.createdAt)) + '</div>' +
    (j.text ? '<p class="d-text">' + esc(j.text) + '</p>' : '') + contact +
    '<div class="row mt14"><button type="button" class="btn fav-lg" data-act="fav" aria-pressed="' + fav + '">' + HEART + '<span>' + (fav ? 'Сақланган' : 'Сақлаб қўйиш') + '</span></button></div>' +
    tipHtml(j.kind) +
    (j.sample ? '<p class="hint mt12">Бу намуна эълон. Илова қандай кўринишини кўрсатиш учун қўйилган.</p>' : '') + owner;
}
function openDetail(id) { var j = findJob(id); if (!j) return; lastSig = JSON.stringify(j); openSheet('detail', detailHtml(j), id); }

/* ---------- янги эълон шакли ---------- */
function formHtml() {
  var K = KIND[S.kind];
  var opts = function (arr) { return '<option value="" disabled selected>Танланг…</option>' + arr.map(function (x) { return '<option value="' + esc(x) + '">' + esc(x) + '</option>'; }).join(''); };
  return '<form id="jobForm" novalidate><div class="sheet-head"><h2 id="sheetTitle">' + esc(K.sheet) + '</h2><button type="button" class="icon-btn" data-act="close" aria-label="Ёпиш">' + XICON + '</button></div>' +
    '<div class="field"><span class="lbl">Эълон тури</span><div class="kind"><label><input type="radio" name="kind" value="vacancy"' + (S.kind === 'vacancy' ? ' checked' : '') + '>Иш бераман</label><label><input type="radio" name="kind" value="resume"' + (S.kind === 'resume' ? ' checked' : '') + '>Иш излайман</label></div></div>' +
    '<div class="field" id="fd-title"><label for="f-title" id="l-title">' + esc(K.what) + '</label><input class="inp" id="f-title" maxlength="' + LIMITS.title + '" autocomplete="off" placeholder="' + esc(K.ph) + '" aria-describedby="e-title"><p class="err" id="e-title"></p></div>' +
    '<div class="field" id="fd-who"><label for="f-who" id="l-who">' + esc(K.who) + ' <span class="opt">(ихтиёрий)</span></label><input class="inp" id="f-who" maxlength="' + LIMITS.who + '" autocomplete="off" aria-describedby="e-who"><p class="err" id="e-who"></p></div>' +
    '<div class="field" id="fd-field"><label for="f-field">Соҳа</label><select class="inp" id="f-field" aria-describedby="e-field">' + opts(FIELDS) + '</select><p class="err" id="e-field"></p></div>' +
    '<div class="field" id="fd-pay"><span class="lbl" id="l-pay">' + esc(K.pay) + ' (сўмда, ойига)</span><div class="row"><input class="inp w120" id="f-from" inputmode="numeric" autocomplete="off" placeholder="Дан" aria-label="Маош, дан"><input class="inp w120" id="f-to" inputmode="numeric" autocomplete="off" placeholder="Гача (ихтиёрий)" aria-label="Маош, гача"></div>' +
    '<p class="hint" id="h-pay"></p><label class="check"><input type="checkbox" id="f-nego"> Маош келишилади</label><p class="err" id="e-pay"></p></div>' +
    '<div class="field" id="fd-region"><label for="f-region">Ҳудуд</label><select class="inp" id="f-region" aria-describedby="e-region">' + opts(REGIONS) + '</select><p class="err" id="e-region"></p></div>' +
    '<div class="field"><label for="f-sched">Иш тартиби <span class="opt">(ихтиёрий)</span></label><select class="inp" id="f-sched"><option value="">Кўрсатилмаган</option>' + SCHEDULES.map(function (x) { return '<option value="' + esc(x) + '">' + esc(x) + '</option>'; }).join('') + '</select></div>' +
    '<div class="field" id="fd-phone"><label for="f-phone">Телефон рақами</label><div class="phone-in"><span>+998</span><input id="f-phone" type="tel" inputmode="numeric" autocomplete="tel-national" placeholder="90 123 45 67" aria-describedby="e-phone h-phone"></div><p class="hint" id="h-phone">Рақамингиз эълонда барчага кўринади.</p><p class="err" id="e-phone"></p></div>' +
    '<div class="field" id="fd-text"><label for="f-text" id="l-text">Тавсиф <span class="opt">(ихтиёрий)</span></label><textarea class="inp" id="f-text" maxlength="' + LIMITS.text + '" placeholder="' + esc(K.textPh) + '" aria-describedby="h-text e-text"></textarea><p class="hint" id="h-text">0 / ' + LIMITS.text + '. Паспорт, карта рақами ва уй манзилини ёзманг.</p><p class="err" id="e-text"></p></div>' +
    '<button type="submit" class="btn primary submit" id="submitBtn">Эълонни жойлаш</button></form>';
}
function openForm() { openSheet('form', formHtml()); }
function applyKindToForm(k) {
  var K = KIND[k];
  $('#sheetTitle').textContent = K.sheet; $('#l-title').textContent = K.what; $('#f-title').placeholder = K.ph;
  $('#l-who').innerHTML = esc(K.who) + ' <span class="opt">(ихтиёрий)</span>'; $('#l-pay').textContent = K.pay + ' (сўмда, ойига)'; $('#f-text').placeholder = K.textPh;
}
function fmtPhoneInput(el) {
  var pos = el.selectionStart == null ? el.value.length : el.selectionStart, before = el.value.slice(0, pos).replace(/\D/g, '').length;
  var d = el.value.replace(/\D/g, ''); if (d.indexOf('998') === 0 && d.length > 9) d = d.slice(3); d = d.slice(0, 9);
  var v = [d.slice(0, 2), d.slice(2, 5), d.slice(5, 7), d.slice(7, 9)].filter(Boolean).join(' '); el.value = v;
  var c = 0, i = 0; for (; i < v.length && c < before; i++) { if (/\d/.test(v[i])) c++; }
  try { el.setSelectionRange(i, i); } catch (e) {}
}
function setErr(k, m) { var e = $('#e-' + k), f = $('#fd-' + k); if (e) e.textContent = m || ''; if (f) f.classList.toggle('bad', !!m); }
function submitForm(form) {
  var g = function (id) { return form.querySelector('#' + id); };
  var kind = form.querySelector('input[name=kind]:checked').value;
  var title = cleanText(g('f-title').value, LIMITS.title).trim(), who = cleanText(g('f-who').value, LIMITS.who).trim();
  var field = g('f-field').value, region = g('f-region').value, nego = g('f-nego').checked;
  var from = parseInt(g('f-from').value.replace(/\D/g, '') || '0', 10), to = parseInt(g('f-to').value.replace(/\D/g, '') || '0', 10);
  var phone = g('f-phone').value.replace(/\D/g, ''), text = cleanText(g('f-text').value, LIMITS.text).trim(), sched = g('f-sched').value, err = {};
  if (title.length < 3) err.title = 'Номини ёзинг (камида 3 та белги).';
  else if (textProblem(title)) err.title = textProblem(title);
  if (who && textProblem(who)) err.who = textProblem(who);
  if (FIELDS.indexOf(field) < 0) err.field = 'Соҳани танланг.';
  if (!nego && !(from > 0)) err.pay = 'Маошни ёзинг ёки «Маош келишилади»ни белгиланг.';
  else if (!nego && (from > 1e10 || to > 1e10)) err.pay = 'Сумма жуда катта.';
  else if (!nego && to && to < from) err.pay = '«Гача» сумма «Дан»дан кичик бўлмасин.';
  if (REGIONS.indexOf(region) < 0) err.region = 'Ҳудудни танланг.';
  if (!/^\d{9}$/.test(phone)) err.phone = 'Телефон рақами тўлиқ эмас. 9 та рақам керак.';
  if (text && textProblem(text)) err.text = textProblem(text);
  var order = [['title', 'f-title'], ['who', 'f-who'], ['field', 'f-field'], ['pay', 'f-from'], ['region', 'f-region'], ['phone', 'f-phone'], ['text', 'f-text']], first = null;
  order.forEach(function (o) { setErr(o[0], err[o[0]]); if (err[o[0]] && !first) first = o[1]; });
  if (first) { g(first).focus(); return; }
  var last = parseInt(lsGet(LAST_KEY) || '0', 10) || 0, wait = LIMITS.cooldownMs - (Date.now() - last);
  if (wait > 0) { toast('Бироз кутинг: ' + Math.ceil(wait / 1000) + ' сониядан кейин қайта уриниб кўринг.'); return; }
  var job = norm({ id: newId(), kind: kind, title: title, who: who, field: field, payFrom: nego ? null : from, payTo: (nego || !to) ? null : to, region: region, schedule: sched, phone: '998' + phone, text: text, createdAt: Date.now(), closed: false, sample: false });
  if (!job) { toast('Эълонни текшириб бўлмади.'); return; }
  try {
    store.add(job); lsSet(LAST_KEY, String(Date.now()));
  } catch (e) {
    toast(e && e.message === 'limit' ? 'Эълонлар жуда кўп. Эскиларини ўчиринг.' : 'Сақлаб бўлмади. Телефон хотирасини текширинг.');
    return;
  }
  closeSheet(); resetFilters(); S.kind = kind; syncUi(); render();
  window.scrollTo({ top: 0, behavior: 'smooth' }); toast('Эълон жойланди');
}

/* ---------- ҳодисалар ---------- */
$('#q').addEventListener('input', function (e) { S.q = e.target.value.slice(0, 60); renderList(); });
$('#region').addEventListener('change', function (e) { S.region = e.target.value; renderList(); });
$('#sort').addEventListener('change', function (e) { S.sort = e.target.value; renderList(); });
$('#favBtn').addEventListener('click', function () { S.fav = !S.fav; syncUi(); renderList(); });
$('#chips').addEventListener('click', function (e) { var b = e.target.closest('[data-field]'); if (!b) return; S.field = b.getAttribute('data-field'); syncUi(); renderList(); });
document.querySelector('.switch').addEventListener('click', function (e) { var b = e.target.closest('[data-kind]'); if (!b) return; S.kind = b.getAttribute('data-kind'); syncUi(); render(); });
$('#fab').addEventListener('click', openForm);
$('#note').addEventListener('click', function (e) {
  if (!e.target.closest('[data-act="rmsamples"]')) return;
  try { store.removeSamples(); render(); toast('Намуна эълонлар ўчирилди'); } catch (x) { toast('Ўчириб бўлмади.'); }
});
$('#list').addEventListener('click', function (e) {
  var f = e.target.closest('[data-fav]'); if (f) { toggleFav(f.getAttribute('data-fav')); return; }
  var o = e.target.closest('[data-open]'); if (o) { openDetail(o.getAttribute('data-open')); return; }
  var a = e.target.closest('[data-act]'); if (!a) return; var k = a.getAttribute('data-act');
  if (k === 'clear') { resetFilters(); renderList(); } else if (k === 'add') openForm();
});
$('#sheet').addEventListener('click', function (e) { if (e.target.classList.contains('backdrop')) closeSheet(); });
document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && sheetKind) closeSheet(); });

$('#panel').addEventListener('click', function (e) {
  var t = e.target.closest('[data-act]'); if (!t) return; var k = t.getAttribute('data-act'), id = sheetId;
  if (k === 'close') closeSheet();
  else if (k === 'fav') toggleFav(id);
  else if (k === 'copy') {
    var j = findJob(id); if (!j) return; var txt = fmtPhone(j.phone);
    var fb = function () { var n = $('#phoneText'); if (n) { var r = document.createRange(); r.selectNodeContents(n); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); } toast('Рақам белгиланди. Нусха олинг.'); };
    try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function () { toast('Рақамдан нусха олинди'); }, fb); else fb(); } catch (x) { fb(); }
  }
  else if (k === 'closed') {
    var j2 = findJob(id); if (!j2) return;
    try { store.update(id, { closed: !j2.closed }); render(); refreshDetail(); toast(!j2.closed ? 'Эълон ёпилди' : 'Эълон яна фаол'); } catch (x) { toast('Ўзгартириб бўлмади. Қайта уриниб кўринг.'); }
  }
  else if (k === 'del') { var cb = $('#confirmBox'); if (cb) { cb.hidden = false; t.hidden = true; var y = cb.querySelector('[data-act="delno"]'); if (y) y.focus(); } }
  else if (k === 'delno') { var cb2 = $('#confirmBox'); if (cb2) cb2.hidden = true; var d = document.querySelector('#panel [data-act="del"]'); if (d) { d.hidden = false; d.focus(); } }
  else if (k === 'delyes') {
    try { store.remove(id); favs.delete(id); saveFavs(); closeSheet(); render(); toast('Эълон ўчирилди'); } catch (x) { toast('Ўчириб бўлмади. Қайта уриниб кўринг.'); }
  }
});
function refreshDetail() {
  if (sheetKind !== 'detail') return;
  var j = findJob(sheetId); if (!j) return;
  var s = JSON.stringify(j); if (s === lastSig) return; lastSig = s;
  var p = $('#panel'), top = p.scrollTop; p.innerHTML = detailHtml(j); p.scrollTop = top;
  var f = p.querySelector('[data-act="close"]'); if (f) f.focus();
}
$('#panel').addEventListener('input', function (e) {
  var t = e.target;
  if (t.id === 'f-phone') fmtPhoneInput(t);
  else if (t.id === 'f-from' || t.id === 'f-to') {
    t.value = t.value.replace(/\D/g, '').slice(0, 11);
    var a = parseInt($('#f-from').value || '0', 10), b = parseInt($('#f-to').value || '0', 10);
    $('#h-pay').textContent = a ? (fmtNum(a) + (b ? ' – ' + fmtNum(b) : '') + ' сўм') : '';
  }
  else if (t.id === 'f-text') $('#h-text').textContent = t.value.length + ' / ' + LIMITS.text + '. Паспорт, карта рақами ва уй манзилини ёзманг.';
});
$('#panel').addEventListener('change', function (e) {
  var t = e.target;
  if (t.id === 'f-nego') {
    $('#f-from').disabled = t.checked; $('#f-to').disabled = t.checked;
    if (t.checked) { $('#f-from').value = ''; $('#f-to').value = ''; $('#h-pay').textContent = ''; setErr('pay', ''); }
  } else if (t.name === 'kind') applyKindToForm(t.value);
});
$('#panel').addEventListener('submit', function (e) { e.preventDefault(); if (e.target.id === 'jobForm') submitForm(e.target); });

/* ---------- ишга тушириш ---------- */
renderTools(); renderChips();
store.load();
syncUi(); render();
/* Интернетда (https) очилганда оффлайн кэш ёқилади. Телефондаги иловада керак эмас. */
if ('serviceWorker' in navigator && location.protocol === 'https:' && location.hostname !== 'localhost') {
  window.addEventListener('load', function () { navigator.serviceWorker.register('sw.js').catch(function () {}); });
}
})();
