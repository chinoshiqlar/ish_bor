#!/usr/bin/env python3
"""
`npx cap add android` дан кейин ишга тушади.
1) Android созламаларини хавфсиз қилади (захира нусха ва очиқ (шифрланмаган) трафик ўчирилади).
2) Иконкаларни қўяди.
3) Release APK ни имзолаш ва версия рақами учун Gradle созламасини қўшади.
"""
import pathlib
import re
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
APP = ROOT / "android" / "app"
MAIN = APP / "src" / "main"
MANIFEST = MAIN / "AndroidManifest.xml"
BUILD_GRADLE = APP / "build.gradle"


def fail(msg):
    print("ХАТО: " + msg)
    sys.exit(1)


if not MANIFEST.exists() or not BUILD_GRADLE.exists():
    fail("android лойиҳаси топилмади. Аввал `npx cap add android` ни ишга туширинг.")

# --- 1. AndroidManifest.xml ---
text = MANIFEST.read_text(encoding="utf-8")
text = re.sub(r'android:allowBackup="true"', 'android:allowBackup="false"', text)
if "android:allowBackup" not in text:
    text = text.replace("<application", '<application\n        android:allowBackup="false"', 1)
if "usesCleartextTraffic" not in text:
    text = text.replace(
        "<application",
        '<application\n        android:usesCleartextTraffic="false"'
        '\n        android:networkSecurityConfig="@xml/network_security_config"',
        1,
    )
MANIFEST.write_text(text, encoding="utf-8")

xml_dir = MAIN / "res" / "xml"
xml_dir.mkdir(parents=True, exist_ok=True)
(xml_dir / "network_security_config.xml").write_text(
    """<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
""",
    encoding="utf-8",
)

# --- 2. Иконкалар ---
src = ROOT / "android-res"
dst = MAIN / "res"
count = 0
for f in src.rglob("*"):
    if f.is_file():
        target = dst / f.relative_to(src)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, target)
        count += 1
print("Иконка ва ресурс файллари нусхаланди: %d" % count)

# --- 3. Gradle: имзолаш ва версия ---
marker = "// --- Иш Бор: хавфсиз release йиғиш ---"
gradle = BUILD_GRADLE.read_text(encoding="utf-8")
if marker not in gradle:
    gradle += """

%s
def ishKeystore = System.getenv("KEYSTORE_PATH")
android {
    defaultConfig {
        versionCode Integer.parseInt(System.getenv("GITHUB_RUN_NUMBER") ?: "1")
        versionName "1.0." + (System.getenv("GITHUB_RUN_NUMBER") ?: "1")
    }
    if (ishKeystore) {
        signingConfigs {
            ishbor {
                storeFile file(ishKeystore)
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS")
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            debuggable false
            minifyEnabled false
            if (ishKeystore) {
                signingConfig signingConfigs.ishbor
            }
        }
    }
    lint {
        checkReleaseBuilds false
        abortOnError false
    }
}
""" % marker
    BUILD_GRADLE.write_text(gradle, encoding="utf-8")

print("Android лойиҳаси тайёр.")
